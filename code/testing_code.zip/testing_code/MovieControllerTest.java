package com.moviefinder.test.controller;


import com.moviefinder.controller.MovieController;
import com.moviefinder.repository.MovieRepository;
import com.moviefinder.service.MovieService;
import com.moviefinder.test.service.MovieServiceTest;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;


@RunWith(SpringRunner.class)
public class MovieControllerTest {

    @TestConfiguration
    static class MovieControllerTestConfig {

    @Bean
    public MovieService movieService() {
        return new MovieServiceTest();

        }
    }

    @Autowired
    private MovieService movieService;

    @MockBean
    private MovieRepository movieRepository;



}
