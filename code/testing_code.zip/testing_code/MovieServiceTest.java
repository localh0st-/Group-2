package com.moviefinder.test.service;

import com.moviefinder.bean.Movie;
import com.moviefinder.repository.MovieRepository;
import com.moviefinder.service.MovieService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

@Service
public class MovieServiceTest implements MovieService {

    @Autowired
    private MovieRepository movieRepository;

    public List getMovieTitle(String title) {

        return movieRepository.findByTitleContainingIgnoreCase(title);
    }

}
