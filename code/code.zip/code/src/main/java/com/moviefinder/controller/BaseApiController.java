package com.moviefinder.controller;

import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("/api")
public abstract class BaseApiController {
}
