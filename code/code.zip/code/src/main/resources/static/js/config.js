module.exports= {
    apiURL:'https://api-gate2.movieglu.com/',
    apiKey:'lLMQtkluNn9F0hGBHlbs740oXx78CVxA3wmlAAeq',
    Username:'DAWI',
    Authorization: 'Basic REFXSTpBcXpTQlp2dW9GMU8=',
    territory: 'US',
    apiversion: 'v200',
    geolocation:'33.803283;-84.201178'
}